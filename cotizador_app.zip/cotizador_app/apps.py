from django.apps import AppConfig


class CotizadorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cotizador_app'
